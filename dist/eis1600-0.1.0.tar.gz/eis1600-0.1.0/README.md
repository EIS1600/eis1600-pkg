# EIS1600 Tools

## Installation
```angular2html
pip install 
```

## Usage

Execute inside the directory of a work which shall be disassembled into MUI files (this directory holds the .EIS1600 file)

```
$ cd <uri>
$ disassemble_into_mui_files.py <uri>.EIS1600
```